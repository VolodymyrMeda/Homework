from distutils.core import setup

setup(name='Finance Manager',
      version='1.0',
      packages=['mainbot', 'mainbot/QueueLinked'],
      description='python telegram bot for managing your spends',
      url='@financemanbot',
      author='Volodymyr Meda',
      author_email='meda@ucu.edu.ua',
      platforms='Telegram'
      )
